﻿namespace Services.Constants
{
    public class Constants
    {
        public static readonly string ConnectionStringSection = "CustomerManagementDBConnection";
    }

}